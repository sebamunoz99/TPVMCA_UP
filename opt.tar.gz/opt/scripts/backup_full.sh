#!/bin/bash

ORIGEN=$1
DESTINO=$2
DIA=$(date +%Y%m%d)

if [ -z "$ORIGEN" ] && [ -z "$DESTINO" ]; then
	echo "Error. No se ha ingresado ningún argumento."; echo "Para más información, ejecute el script con el argumento '-help'.";
	exit 1;
elif [ "$ORIGEN" = "-help" ]; then
	echo "----------------------------------------------------------------------------------------"; echo "";
	echo "Manual de uso de 'backup_full.sh':";
	echo "Para ejecutar correctamente el script se debe ejecutar el siguiente comando en consola:";
	echo "bash /opt/scripts/backup_full.sh [ORIGEN] [DESTINO]";
	echo "donde [ORIGEN] y [DESTINO] son directorios."; echo ""; 
	echo "----------------------------------------------------------------------------------------";
	exit 0;
elif [ "$#" -ne 2 ]; then
	echo "Error: se requieren exactamente 2 argumentos."; echo "Para más información, ejecute el script con el argumento '-help'.";
	exit 1;
elif [ ! -d "$ORIGEN" ]; then
	echo "Error: ORIGEN debe ser un directorio."; echo "Para mas información, ejecute el script con el argumento '-help'.";
	exit 1;
elif [ ! -d "$DESTINO" ]; then
	echo "Error: DESTINO debe ser un directorio."; echo "Para mas información, ejecute el script con el argumento '-help'.";
	exit 1;
else
	DIR=$(basename "$ORIGEN")
	FILE=${DIR}_bkp_${DIA}.tar.gz
	tar -czf "${DESTINO}/${FILE}" "${ORIGEN}"
	if [ "$?" -eq 0 ]; then 
		echo "Finalizó la compresión, la cual se ha guardado en ${DESTINO}";
		exit 0;
	else
		echo "Error en la compresión.";
		exit 1;
	fi
fi
