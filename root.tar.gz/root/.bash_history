history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
hostname
hostnamectl set-hostname TPServer
pi /etc/hosts
vi /etc/hosts
reboot
hostname
hostnamectl
vi /etc/apt/sources.list
apt update
apt upgrade
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
apt list --upgradable
apt upgrade
reboot
apt full-upgrade -y
apt autoremove -y
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
apt upgrade --without-new-pkgs -y
apt full-upgrade -y
apt autoremove -y
apt clean
reboot
cat /etc/debian_version 
apt install ssh-server
apt install ssh
ip
ip -address
ip address
exit
vi /etc/ssh/sshd_config
vi /etc/ssh/sshd_config 
systemctl restart ssh
systemctl status ssh
ssh-keygen
cd /root/.ssh/
ls -la
ls -l
cat /root/.ssh/id_rsa.pub  >> /root/.ssh/authorized_keys
ls -l
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys 
ip a
exit
vi /etc/ssh/sshd_config 
systemctl restart ssh
systemctl status ssh
exit
exit
apt update
apt list --upgradable 
apt install apache -y && apt install php -y && apt install libapache2-mod-php -y && apt install php-mysql -y
apt install apache2 -y && apt install php -y && apt install libapache2-mod-php -y && apt install php-mysql -y
php -v
systemctl status apache2
ls /root
tar xvzf Material_Adicional_TPVMCA.tar.gz /root
cd /root/
tar xvzf Material_Adicional_TPVMCA.tar.gz /root
tar xvzf Material_Adicional_TPVMCA.tar.gz
ls -la
cd /root/Material_Adicional_TPVMCA/
ls -la
cat clave_privada.txt 
cat clave_publica.pub 
cd ..
cd /root/.ssh/
cat authorized_keys 
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys 
cat authorized_keys 
ls -l
cd ../Material_Adicional_TPVMCA/
ls -l
chmod clave_privada.txt 60
chmod clave_privada.txt 600
chmod 600 clave_privada.txt 
ls -l
cd ../.ssh/
cd /var/www/html/
ls -l
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls -l
systemctl restart apache2
rm index.html 
ls -l
systemctl restart apache2
cat index.php 
tail -n 20 /var/log/apache2/error.log 
apt install mariadb-server -y
systemctl status mariadb
mariadb
cd /root/Material_Adicional_TPVMCA/
vi db.sql 
mariadb
mariadb < db.sql 
mariadb -e "SHOW DATABASES"
exit
exit
ip a
reboot
ip a
ip a
vim /etc/network/interfaces
ip a
vim /etc/network/interfaces
systemctl restart networking.service 
ip a
ifup enp0s3
reboot
vim /etc/network/interfaces
vim /etc/network/interfaces
systemctl restart networking.service 
vim /etc/network/interfaces
systemctl restart networking.service 
ifup enp0s3
reboot
ip a
exit
exit
ip a
ping -c 3 8.8.8.8
cat /etc/network/interfaces
runlevel 0
init 0
lsblk 
fdisk /dev/sdc 
lsblk 
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
lsblk 
lsblk -f
cd /
cd ..
cd /root/
cd ..
mkdir www_dir
mkdir backup_dir
mount /dev/sdc1 legajos/
mount /dev/sdc1 /legajos/
mount /dev/sdc1 /legajos
ls -la
mount /dev/sdc1 www_dir/
mount /dev/sdc2 backup_dir/
cd /etc/
vim fstab 
reboot
lsblk 
cat /proc/partitions 
cat /proc/partitions >> /opt/particion
cd /opt/
cat particion 
df -h
cd ..
cd etc/apache2/
ls -l
cd ..
ls -l
cd ../var/www/
ls -l
ls -la
cd html/
ls -la
mv index.php /www_dir/
mv logo.png /www_dir/
ls -la
cd ..
cd ../..
find / -name 000-default.conf
find / -name apache2
vim /etc/apache2
vim /etc/apache2/apache2.conf 
find / -name apache2.conf
vim /etc/apache2/apache2.conf 
vim /etc/apache2/sites-available/000-default.conf
apachectl configtest
systemctl restart apache2
pwd
cd /opt/
ls
mkdir scripts
cd scripts/
basename
man basename
basename /opt/scripts/
init 0
ip a
cd /opt/
cd scripts/
vim backup_full.sh
sh backup_full.sh 
sh backup_full.sh Hola Arg2
sh backup_full.sh Hola
vim backup_full.sh
quit
exit
vim backup_full.sh
cd /opt/scripts/
cat backup_full.sh 
vim backup_full.sh
sh backup_full.sh -help
vim backup_full.sh
sh backup_full.sh -help
vim backup_full.sh
sh backup_full.sh -help
vim backup_full.sh
sh backup_full.sh -help
vim backup_full.sh
sh backup_full.sh -help
vim backup_full.sh
sh backup_full.sh -help
vim backup_full.sh
sh backup_full.sh -help
vim backup_full.sh
bash backup_full.sh -help
bash backup_full.sh -hola
bash backup_full.sh arg1 -help
bash backup_full.sh -help hola
vim backup_full.sh
vim backup_full.sh
vim backup_full.sh
vim backup_full.sh
vim backup_full.sh
vim backup_full.sh
init 0
vim backup_full.sh
cd /opt/scripts/
vim backup_full.sh
bash backup_full.sh
bash backup_full.sh -help
bash backup_full.sh /opt/scripts /test
vim backup_full.sh
vim backup_full.sh
bash backup_full.sh /opt/scripts /test
vim backup_full.sh
bash backup_full.sh /opt/scripts /test /hola
vim backup_full.sh
bash backup_full.sh /opt/scripts /test /hola
vim backup_full.sh

vim backup_full.sh
bash backup_full.sh
bash backup_full.sh -help
bash backup_full.sh help
bash backup_full.sh help help help
bash backup_full.sh /opt
bash backup_full.sh /opt /inventado
bash backup_full.sh /otx /inventado
bash backup_full.sh /opt /opt
vim backup_full.sh
bash backup_full.sh /opt
vim backup_full.sh
vim backup_full.sh
bash backup_full.sh /opt
bash backup_full.sh /opt /opt
bash backup_full.sh -help
vim backup_full.sh
bash backup_full.sh /opt /bin
bash backup_full.sh /home/compartido/dir1/ /bin
vim backup_full.sh
man tar
man tar
vim backup_full.sh
vim /opt/scripts/backup_full.sh
chmod 755 /opt/scripts/backup_full.sh 
vim /opt/scripts/backup_full.sh
vim /etc/crontab 
vim /etc/crontab 
vim /etc/crontab 
vim /etc/crontab 
vim /etc/crontab 
init 1
reboot
ls -la /backup_dir/
vim /etc/crontab 

ls -la /backup_dir/
exit
